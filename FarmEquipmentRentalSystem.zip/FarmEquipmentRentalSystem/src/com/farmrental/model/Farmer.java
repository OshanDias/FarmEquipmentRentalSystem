package com.farmrental.model;

import java.sql.Timestamp;

/**
 * Farmer Model (POJO - Plain Old Java Object)
 * Represents a farmer in the farm equipment rental system
 */
public class Farmer {
    
    private int farmerId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String nic;
    private String address;
    private String farmLocation;
    private double farmSize;
    private Timestamp createdAt;
    
    // Default Constructor
    public Farmer() {
    }
    
    // Constructor for new farmer (without ID)
    public Farmer(String firstName, String lastName, String email, String phone, 
                  String nic, String address, String farmLocation, double farmSize) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.nic = nic;
        this.address = address;
        this.farmLocation = farmLocation;
        this.farmSize = farmSize;
    }
    
    // Full Constructor (with ID)
    public Farmer(int farmerId, String firstName, String lastName, String email, 
                  String phone, String nic, String address, String farmLocation, double farmSize) {
        this.farmerId = farmerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.nic = nic;
        this.address = address;
        this.farmLocation = farmLocation;
        this.farmSize = farmSize;
    }
    
    // Getters and Setters
    public int getFarmerId() {
        return farmerId;
    }
    
    public void setFarmerId(int farmerId) {
        this.farmerId = farmerId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getNic() {
        return nic;
    }
    
    public void setNic(String nic) {
        this.nic = nic;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getFarmLocation() {
        return farmLocation;
    }
    
    public void setFarmLocation(String farmLocation) {
        this.farmLocation = farmLocation;
    }
    
    public double getFarmSize() {
        return farmSize;
    }
    
    public void setFarmSize(double farmSize) {
        this.farmSize = farmSize;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    // Helper method to get full name
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    @Override
    public String toString() {
        return "Farmer{" +
                "farmerId=" + farmerId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", farmLocation='" + farmLocation + '\'' +
                ", farmSize=" + farmSize +
                '}';
    }
}