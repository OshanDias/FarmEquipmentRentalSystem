package com.farmrental.model;

import java.sql.Timestamp;

/**
 * Equipment Model (POJO)
 * Represents farm equipment in the rental system
 */
public class Equipment {
    
    private int equipmentId;
    private int categoryId;
    private String equipmentNumber;
    private String brand;
    private String model;
    private int year;
    private String fuelType;
    private String conditionStatus;
    private String status;
    private int horsePower;
    private Timestamp createdAt;
    
    // Additional fields from JOIN with equipment_categories
    private String categoryName;
    private double dailyRate;
    
    // Default Constructor
    public Equipment() {
    }
    
    // Constructor for new equipment (without ID)
    public Equipment(int categoryId, String equipmentNumber, String brand, String model, 
                     int year, String fuelType, String conditionStatus, String status, int horsePower) {
        this.categoryId = categoryId;
        this.equipmentNumber = equipmentNumber;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.fuelType = fuelType;
        this.conditionStatus = conditionStatus;
        this.status = status;
        this.horsePower = horsePower;
    }
    
    // Full Constructor (with ID)
    public Equipment(int equipmentId, int categoryId, String equipmentNumber, String brand, 
                     String model, int year, String fuelType, String conditionStatus, 
                     String status, int horsePower) {
        this.equipmentId = equipmentId;
        this.categoryId = categoryId;
        this.equipmentNumber = equipmentNumber;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.fuelType = fuelType;
        this.conditionStatus = conditionStatus;
        this.status = status;
        this.horsePower = horsePower;
    }
    
    // Getters and Setters
    public int getEquipmentId() {
        return equipmentId;
    }
    
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }
    
    public int getCategoryId() {
        return categoryId;
    }
    
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
    
    public String getEquipmentNumber() {
        return equipmentNumber;
    }
    
    public void setEquipmentNumber(String equipmentNumber) {
        this.equipmentNumber = equipmentNumber;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
    }
    
    public String getFuelType() {
        return fuelType;
    }
    
    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }
    
    public String getConditionStatus() {
        return conditionStatus;
    }
    
    public void setConditionStatus(String conditionStatus) {
        this.conditionStatus = conditionStatus;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public int getHorsePower() {
        return horsePower;
    }
    
    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getCategoryName() {
        return categoryName;
    }
    
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    
    public double getDailyRate() {
        return dailyRate;
    }
    
    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }
    
    // Helper method to get full name
    public String getFullName() {
        return brand + " " + model + " (" + year + ")";
    }
    
    @Override
    public String toString() {
        return "Equipment{" +
                "equipmentId=" + equipmentId +
                ", equipmentNumber='" + equipmentNumber + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", status='" + status + '\'' +
                '}';
    }
}