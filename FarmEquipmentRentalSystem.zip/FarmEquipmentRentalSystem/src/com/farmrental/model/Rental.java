package com.farmrental.model;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * Rental Model (POJO)
 * Represents a rental transaction in the farm equipment rental system
 */
public class Rental {
    
    private int rentalId;
    private int farmerId;
    private int equipmentId;
    private Date rentalDate;
    private Date returnDate;
    private Date actualReturnDate;
    private int totalDays;
    private double dailyRate;
    private double totalAmount;
    private double depositAmount;
    private String status;
    private String purpose;
    private String notes;
    private Timestamp createdAt;
    
    // For display purposes (from JOINs)
    private String farmerName;
    private String farmerPhone;
    private String equipmentNumber;
    private String equipmentName;
    
    // Default Constructor
    public Rental() {
    }
    
    // Constructor for new rental (without ID)
    public Rental(int farmerId, int equipmentId, Date rentalDate, Date returnDate, 
                  int totalDays, double dailyRate, double totalAmount, 
                  double depositAmount, String status, String purpose) {
        this.farmerId = farmerId;
        this.equipmentId = equipmentId;
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
        this.totalDays = totalDays;
        this.dailyRate = dailyRate;
        this.totalAmount = totalAmount;
        this.depositAmount = depositAmount;
        this.status = status;
        this.purpose = purpose;
    }
    
    // Full Constructor
    public Rental(int rentalId, int farmerId, int equipmentId, Date rentalDate, 
                  Date returnDate, Date actualReturnDate, int totalDays, 
                  double dailyRate, double totalAmount, double depositAmount, 
                  String status, String purpose, String notes) {
        this.rentalId = rentalId;
        this.farmerId = farmerId;
        this.equipmentId = equipmentId;
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
        this.actualReturnDate = actualReturnDate;
        this.totalDays = totalDays;
        this.dailyRate = dailyRate;
        this.totalAmount = totalAmount;
        this.depositAmount = depositAmount;
        this.status = status;
        this.purpose = purpose;
        this.notes = notes;
    }
    
    // Getters and Setters
    public int getRentalId() {
        return rentalId;
    }
    
    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }
    
    public int getFarmerId() {
        return farmerId;
    }
    
    public void setFarmerId(int farmerId) {
        this.farmerId = farmerId;
    }
    
    public int getEquipmentId() {
        return equipmentId;
    }
    
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }
    
    public Date getRentalDate() {
        return rentalDate;
    }
    
    public void setRentalDate(Date rentalDate) {
        this.rentalDate = rentalDate;
    }
    
    public Date getReturnDate() {
        return returnDate;
    }
    
    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }
    
    public Date getActualReturnDate() {
        return actualReturnDate;
    }
    
    public void setActualReturnDate(Date actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }
    
    public int getTotalDays() {
        return totalDays;
    }
    
    public void setTotalDays(int totalDays) {
        this.totalDays = totalDays;
    }
    
    public double getDailyRate() {
        return dailyRate;
    }
    
    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public double getDepositAmount() {
        return depositAmount;
    }
    
    public void setDepositAmount(double depositAmount) {
        this.depositAmount = depositAmount;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getPurpose() {
        return purpose;
    }
    
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
    
    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getFarmerName() {
        return farmerName;
    }
    
    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }
    
    public String getFarmerPhone() {
        return farmerPhone;
    }
    
    public void setFarmerPhone(String farmerPhone) {
        this.farmerPhone = farmerPhone;
    }
    
    public String getEquipmentNumber() {
        return equipmentNumber;
    }
    
    public void setEquipmentNumber(String equipmentNumber) {
        this.equipmentNumber = equipmentNumber;
    }
    
    public String getEquipmentName() {
        return equipmentName;
    }
    
    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }
    
    @Override
    public String toString() {
        return "Rental{" +
                "rentalId=" + rentalId +
                ", farmerId=" + farmerId +
                ", equipmentId=" + equipmentId +
                ", rentalDate=" + rentalDate +
                ", returnDate=" + returnDate +
                ", totalAmount=" + totalAmount +
                ", status='" + status + '\'' +
                '}';
    }
}