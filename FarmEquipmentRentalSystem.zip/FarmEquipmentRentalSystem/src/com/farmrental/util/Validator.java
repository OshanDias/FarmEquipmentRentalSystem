package com.farmrental.util;

import java.sql.Date;
import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Utility class for input validation
 */
public class Validator {
    
    // Email validation pattern
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    
    // Phone validation pattern (Sri Lankan format)
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^0[0-9]{9}$");
    
    // NIC validation patterns (Sri Lankan format)
    private static final Pattern NIC_OLD_PATTERN = 
        Pattern.compile("^[0-9]{9}[VvXx]$");
    private static final Pattern NIC_NEW_PATTERN = 
        Pattern.compile("^[0-9]{12}$");
    
    // Equipment number pattern
    private static final Pattern EQUIPMENT_NUMBER_PATTERN = 
        Pattern.compile("^[A-Z]{3}-[0-9]{3}$");
    
    // Check if string is empty or null
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
    
    // Validate email format
    public static boolean isValidEmail(String email) {
        if (isEmpty(email)) return false;
        return EMAIL_PATTERN.matcher(email).matches();
    }
    
    // Validate phone number
    public static boolean isValidPhone(String phone) {
        if (isEmpty(phone)) return false;
        return PHONE_PATTERN.matcher(phone).matches();
    }
    
    // Validate NIC (both old and new formats)
    public static boolean isValidNIC(String nic) {
        if (isEmpty(nic)) return false;
        return NIC_OLD_PATTERN.matcher(nic).matches() || 
               NIC_NEW_PATTERN.matcher(nic).matches();
    }
    
    // Validate equipment number
    public static boolean isValidEquipmentNumber(String equipmentNumber) {
        if (isEmpty(equipmentNumber)) return false;
        return EQUIPMENT_NUMBER_PATTERN.matcher(equipmentNumber.toUpperCase()).matches();
    }
    
    // Validate date (not in past)
    public static boolean isValidFutureDate(Date date) {
        if (date == null) return false;
        LocalDate inputDate = date.toLocalDate();
        LocalDate today = LocalDate.now();
        return !inputDate.isBefore(today);
    }
    
    // Validate date (not in future)
    public static boolean isValidPastOrTodayDate(Date date) {
        if (date == null) return false;
        LocalDate inputDate = date.toLocalDate();
        LocalDate today = LocalDate.now();
        return !inputDate.isAfter(today);
    }
    
    // Validate date range
    public static boolean isValidDateRange(Date startDate, Date endDate) {
        if (startDate == null || endDate == null) return false;
        return !endDate.before(startDate);
    }
    
    // Validate positive number
    public static boolean isPositiveNumber(double number) {
        return number > 0;
    }
    
    // Validate positive integer
    public static boolean isPositiveInteger(int number) {
        return number > 0;
    }
    
    // Validate string length
    public static boolean isValidLength(String str, int minLength, int maxLength) {
        if (isEmpty(str)) return false;
        int length = str.trim().length();
        return length >= minLength && length <= maxLength;
    }
    
    // Validate year (reasonable range)
    public static boolean isValidYear(int year) {
        int currentYear = LocalDate.now().getYear();
        return year >= 1990 && year <= currentYear + 1;
    }
    
    // Validate that string contains only letters and spaces
    public static boolean isValidName(String name) {
        if (isEmpty(name)) return false;
        return name.matches("^[a-zA-Z ]+$");
    }
    
    // Get validation error message for email
    public static String getEmailError(String email) {
        if (isEmpty(email)) return "Email is required";
        if (!isValidEmail(email)) return "Invalid email format (e.g., name@example.com)";
        return null;
    }
    
    // Get validation error message for phone
    public static String getPhoneError(String phone) {
        if (isEmpty(phone)) return "Phone number is required";
        if (!isValidPhone(phone)) return "Invalid phone number (10 digits starting with 0)";
        return null;
    }
    
    // Get validation error message for NIC
    public static String getNICError(String nic) {
        if (isEmpty(nic)) return "NIC is required";
        if (!isValidNIC(nic)) return "Invalid NIC format (9 digits + V/X or 12 digits)";
        return null;
    }
    
    // Get validation error message for name
    public static String getNameError(String name, String fieldName) {
        if (isEmpty(name)) return fieldName + " is required";
        if (!isValidName(name)) return fieldName + " should contain only letters";
        if (!isValidLength(name, 2, 50)) return fieldName + " must be between 2 and 50 characters";
        return null;
    }
    
    // Get validation error message for equipment number
    public static String getEquipmentNumberError(String equipmentNumber) {
        if (isEmpty(equipmentNumber)) return "Equipment number is required";
        if (!isValidEquipmentNumber(equipmentNumber)) return "Invalid format (e.g., TRC-001)";
        return null;
    }
}