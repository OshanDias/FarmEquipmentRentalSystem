package com.farmrental.view;

import com.farmrental.dao.EquipmentDAO;
import com.farmrental.model.Equipment;
import com.farmrental.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Equipment Management Form - FARM THEME
 */
public class EquipmentForm extends JFrame {
    
    private EquipmentDAO equipmentDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblEquipment;
    private JComboBox<String> cmbCategory;
    private JTextField txtEquipmentNumber;
    private JTextField txtBrand;
    private JTextField txtModel;
    private JTextField txtYear;
    private JComboBox<String> cmbFuelType;
    private JComboBox<String> cmbCondition;
    private JComboBox<String> cmbStatus;
    private JTextField txtHorsePower;
    private JTextField txtSearch;
    
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JButton btnSearch;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedEquipmentId = -1;
    
    public EquipmentForm() {
        equipmentDAO = new EquipmentDAO();
        initComponents();
        loadEquipment();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Equipment Management");
        setSize(1450, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 240, 230));
        
        // Header Panel - Orange
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(210, 180, 140));
        headerPanel.setBounds(0, 0, 1450, 70);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel("🚜 EQUIPMENT MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(new Color(101, 67, 33));
        lblTitle.setBounds(30, 20, 500, 35);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setBounds(1300, 20, 120, 40);
        btnBack.setBackground(new Color(139, 90, 43));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // Left Panel - Equipment Details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(null);
        detailsPanel.setBackground(new Color(250, 245, 235));
        detailsPanel.setBounds(20, 90, 500, 690);
        detailsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Equipment Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(detailsPanel);
        
        // Input Fields
        int yPos = 40;
        int gap = 65;
        
        addLabel(detailsPanel, "Category:", 20, yPos);
        String[] categories = {"Tractor", "Harvester", "Plow", "Sprayer", "Seeder"};
        cmbCategory = addComboBox(detailsPanel, categories, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Equipment Number:", 20, yPos);
        txtEquipmentNumber = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Brand:", 20, yPos);
        txtBrand = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Model:", 20, yPos);
        txtModel = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Year:", 20, yPos);
        txtYear = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Fuel Type:", 20, yPos);
        String[] fuelTypes = {"Diesel", "Petrol", "Electric", "Manual"};
        cmbFuelType = addComboBox(detailsPanel, fuelTypes, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Condition:", 20, yPos);
        String[] conditions = {"Excellent", "Good", "Fair"};
        cmbCondition = addComboBox(detailsPanel, conditions, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Status:", 20, yPos);
        String[] statuses = {"AVAILABLE", "RENTED", "MAINTENANCE"};
        cmbStatus = addComboBox(detailsPanel, statuses, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Horse Power (HP):", 20, yPos);
        txtHorsePower = addTextField(detailsPanel, 20, yPos + 25);
        
        // Action Buttons
        yPos += 60;
        btnAdd = createButton("ADD", 20, yPos, new Color(34, 139, 34));
        btnAdd.addActionListener(e -> addEquipment());
        detailsPanel.add(btnAdd);
        
        btnUpdate = createButton("UPDATE", 125, yPos, new Color(255, 140, 0));
        btnUpdate.addActionListener(e -> updateEquipment());
        detailsPanel.add(btnUpdate);
        
        btnDelete = createButton("DELETE", 230, yPos, new Color(178, 34, 34));
        btnDelete.addActionListener(e -> deleteEquipment());
        detailsPanel.add(btnDelete);
        
        btnClear = createButton("CLEAR", 335, yPos, new Color(139, 90, 43));
        btnClear.addActionListener(e -> clearFields());
        detailsPanel.add(btnClear);
        
        // Right Panel - Equipment Table
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(new Color(250, 245, 235));
        tablePanel.setBounds(540, 90, 890, 690);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Equipment List",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(tablePanel);
        
        // Search Panel
        JLabel lblSearch = new JLabel("🔍 Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSearch.setForeground(new Color(101, 67, 33));
        lblSearch.setBounds(20, 35, 100, 35);
        tablePanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBackground(new Color(255, 250, 240));
        txtSearch.setBounds(120, 35, 350, 35);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        tablePanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 490, 35, new Color(255, 140, 0));
        btnSearch.addActionListener(e -> searchEquipment());
        tablePanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 595, 35, new Color(34, 139, 34));
        btnRefresh.addActionListener(e -> loadEquipment());
        tablePanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Category", "Number", "Brand", "Model", "Year", "HP", "Status", "Rate/Day"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblEquipment = new JTable(tableModel);
        tblEquipment.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tblEquipment.setRowHeight(28);
        tblEquipment.setBackground(new Color(255, 250, 240));
        tblEquipment.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tblEquipment.getTableHeader().setBackground(new Color(210, 180, 140));
        tblEquipment.getTableHeader().setForeground(new Color(101, 67, 33));
        tblEquipment.setSelectionBackground(new Color(255, 140, 0));
        tblEquipment.setSelectionForeground(Color.WHITE);
        
        // Table selection listener
        tblEquipment.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedEquipment();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblEquipment);
        scrollPane.setBounds(20, 90, 850, 580);
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(new Color(101, 67, 33));
        label.setBounds(x, y, 200, 25);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBackground(new Color(255, 250, 240));
        field.setBounds(x, y, 460, 35);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JComboBox<String> addComboBox(JPanel panel, String[] items, int x, int y) {
        JComboBox<String> combo = new JComboBox<>(items);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setBackground(new Color(255, 250, 240));
        combo.setBounds(x, y, 460, 35);
        panel.add(combo);
        return combo;
    }
    
    private JButton createButton(String text, int x, int y, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, 100, 35);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
    
    // Get category ID from name
    private int getCategoryId(String categoryName) {
        switch (categoryName) {
            case "Tractor": return 1;
            case "Harvester": return 2;
            case "Plow": return 3;
            case "Sprayer": return 4;
            case "Seeder": return 5;
            default: return 1;
        }
    }
    
    // Load all equipment
    private void loadEquipment() {
        try {
            tableModel.setRowCount(0);
            List<Equipment> equipmentList = equipmentDAO.getAllEquipment();
            
            for (Equipment equipment : equipmentList) {
                Object[] row = {
                    equipment.getEquipmentId(),
                    equipment.getCategoryName(),
                    equipment.getEquipmentNumber(),
                    equipment.getBrand(),
                    equipment.getModel(),
                    equipment.getYear(),
                    equipment.getHorsePower() + " HP",
                    equipment.getStatus(),
                    "Rs. " + String.format("%.2f", equipment.getDailyRate())
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading equipment: " + e.getMessage());
        }
    }
    
    // Load selected equipment into fields
    private void loadSelectedEquipment() {
        int selectedRow = tblEquipment.getSelectedRow();
        if (selectedRow >= 0) {
            selectedEquipmentId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                Equipment equipment = equipmentDAO.getEquipmentById(selectedEquipmentId);
                if (equipment != null) {
                    cmbCategory.setSelectedItem(equipment.getCategoryName());
                    txtEquipmentNumber.setText(equipment.getEquipmentNumber());
                    txtBrand.setText(equipment.getBrand());
                    txtModel.setText(equipment.getModel());
                    txtYear.setText(String.valueOf(equipment.getYear()));
                    cmbFuelType.setSelectedItem(equipment.getFuelType());
                    cmbCondition.setSelectedItem(equipment.getConditionStatus());
                    cmbStatus.setSelectedItem(equipment.getStatus());
                    txtHorsePower.setText(String.valueOf(equipment.getHorsePower()));
                }
            } catch (SQLException e) {
                showError("Error loading equipment details: " + e.getMessage());
            }
        }
    }
    
    // Add equipment
    private void addEquipment() {
        if (!validateInputs()) return;
        
        try {
            Equipment equipment = new Equipment();
            equipment.setCategoryId(getCategoryId((String) cmbCategory.getSelectedItem()));
            equipment.setEquipmentNumber(txtEquipmentNumber.getText().trim().toUpperCase());
            equipment.setBrand(txtBrand.getText().trim());
            equipment.setModel(txtModel.getText().trim());
            equipment.setYear(Integer.parseInt(txtYear.getText().trim()));
            equipment.setFuelType((String) cmbFuelType.getSelectedItem());
            equipment.setConditionStatus((String) cmbCondition.getSelectedItem());
            equipment.setStatus((String) cmbStatus.getSelectedItem());
            equipment.setHorsePower(Integer.parseInt(txtHorsePower.getText().trim()));
            
            boolean success = equipmentDAO.addEquipment(equipment);
            
            if (success) {
                showSuccess("✅ Equipment added successfully!");
                loadEquipment();
                clearFields();
            } else {
                showError("Failed to add equipment!");
            }
            
        } catch (SQLException e) {
            showError("Error adding equipment: " + e.getMessage());
        } catch (NumberFormatException e) {
            showError("Invalid number format!");
        }
    }
    
    // Update equipment
    private void updateEquipment() {
        if (selectedEquipmentId == -1) {
            showWarning("Please select equipment to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            Equipment equipment = new Equipment();
            equipment.setEquipmentId(selectedEquipmentId);
            equipment.setCategoryId(getCategoryId((String) cmbCategory.getSelectedItem()));
            equipment.setEquipmentNumber(txtEquipmentNumber.getText().trim().toUpperCase());
            equipment.setBrand(txtBrand.getText().trim());
            equipment.setModel(txtModel.getText().trim());
            equipment.setYear(Integer.parseInt(txtYear.getText().trim()));
            equipment.setFuelType((String) cmbFuelType.getSelectedItem());
            equipment.setConditionStatus((String) cmbCondition.getSelectedItem());
            equipment.setStatus((String) cmbStatus.getSelectedItem());
            equipment.setHorsePower(Integer.parseInt(txtHorsePower.getText().trim()));
            
            boolean success = equipmentDAO.updateEquipment(equipment);
            
            if (success) {
                showSuccess("✅ Equipment updated successfully!");
                loadEquipment();
                clearFields();
            } else {
                showError("Failed to update equipment!");
            }
            
        } catch (SQLException e) {
            showError("Error updating equipment: " + e.getMessage());
        } catch (NumberFormatException e) {
            showError("Invalid number format!");
        }
    }
    
    // Delete equipment
    private void deleteEquipment() {
        if (selectedEquipmentId == -1) {
            showWarning("Please select equipment to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this equipment?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = equipmentDAO.deleteEquipment(selectedEquipmentId);
                
                if (success) {
                    showSuccess("✅ Equipment deleted successfully!");
                    loadEquipment();
                    clearFields();
                } else {
                    showError("Failed to delete equipment!");
                }
                
            } catch (SQLException e) {
                showError("Error deleting equipment: " + e.getMessage());
            }
        }
    }
    
    // Search equipment
    private void searchEquipment() {
        String searchTerm = txtSearch.getText().trim();
        
        if (searchTerm.isEmpty()) {
            loadEquipment();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<Equipment> equipmentList = equipmentDAO.searchEquipment(searchTerm);
            
            for (Equipment equipment : equipmentList) {
                Object[] row = {
                    equipment.getEquipmentId(),
                    equipment.getCategoryName(),
                    equipment.getEquipmentNumber(),
                    equipment.getBrand(),
                    equipment.getModel(),
                    equipment.getYear(),
                    equipment.getHorsePower() + " HP",
                    equipment.getStatus(),
                    "Rs. " + String.format("%.2f", equipment.getDailyRate())
                };
                tableModel.addRow(row);
            }
            
            if (equipmentList.isEmpty()) {
                showInfo("No equipment found matching: " + searchTerm);
            }
            
        } catch (SQLException e) {
            showError("Error searching equipment: " + e.getMessage());
        }
    }
    
    // Clear all fields
    private void clearFields() {
        cmbCategory.setSelectedIndex(0);
        txtEquipmentNumber.setText("");
        txtBrand.setText("");
        txtModel.setText("");
        txtYear.setText("");
        cmbFuelType.setSelectedIndex(0);
        cmbCondition.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
        txtHorsePower.setText("");
        txtSearch.setText("");
        selectedEquipmentId = -1;
        tblEquipment.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        String equipmentNumber = txtEquipmentNumber.getText().trim();
        String brand = txtBrand.getText().trim();
        String model = txtModel.getText().trim();
        String year = txtYear.getText().trim();
        String horsePower = txtHorsePower.getText().trim();
        
        if (Validator.isEmpty(equipmentNumber)) {
            showWarning("Equipment number is required!");
            txtEquipmentNumber.requestFocus();
            return false;
        }
        
        if (Validator.isEmpty(brand)) {
            showWarning("Brand is required!");
            txtBrand.requestFocus();
            return false;
        }
        
        if (Validator.isEmpty(model)) {
            showWarning("Model is required!");
            txtModel.requestFocus();
            return false;
        }
        
        try {
            int y = Integer.parseInt(year);
            if (!Validator.isValidYear(y)) {
                showWarning("Invalid year! (1990 - current year + 1)");
                txtYear.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Year must be a number!");
            txtYear.requestFocus();
            return false;
        }
        
        try {
            int hp = Integer.parseInt(horsePower);
            if (hp < 0) {
                showWarning("Horse power cannot be negative!");
                txtHorsePower.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Horse power must be a number!");
            txtHorsePower.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Main for testing
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new EquipmentForm().setVisible(true));
    }
}