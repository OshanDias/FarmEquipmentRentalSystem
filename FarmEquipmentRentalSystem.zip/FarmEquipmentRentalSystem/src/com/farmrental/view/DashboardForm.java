package com.farmrental.view;

import com.farmrental.controller.ReportController;
import com.farmrental.dao.*;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

/**
 * Dashboard Form - FARM THEME
 */
public class DashboardForm extends JFrame {
    
    private FarmerDAO farmerDAO;
    private EquipmentDAO equipmentDAO;
    private RentalDAO rentalDAO;
    
    public DashboardForm() {
        farmerDAO = new FarmerDAO();
        equipmentDAO = new EquipmentDAO();
        rentalDAO = new RentalDAO();
        initComponents();
        loadStatistics();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Farm Equipment Rental System - Dashboard");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 240, 230));
        
        // Header Panel - Warm orange
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(255, 140, 0));
        headerPanel.setBounds(0, 0, 1000, 80);
        add(headerPanel);
        
        // Title with farm icon
        JLabel lblTitle = new JLabel(" FARM EQUIPMENT RENTAL - DASHBOARD");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 25, 700, 35);
        headerPanel.add(lblTitle);
        
        // Logout Button
        JButton btnLogout = createButton(" LOGOUT", 850, 20, 120, 40, new Color(139, 90, 43));
        btnLogout.addActionListener(e -> logout());
        headerPanel.add(btnLogout);
        
        // Statistics Panel
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(null);
        statsPanel.setBackground(new Color(245, 240, 230));
        statsPanel.setBounds(30, 100, 940, 150);
        add(statsPanel);
        
        // Stat Cards
        createStatCard(statsPanel, "👨‍🌾 TOTAL FARMERS", "0", new Color(205, 133, 63), 0);
        createStatCard(statsPanel, " TOTAL EQUIPMENT", "0", new Color(210, 180, 140), 235);
        createStatCard(statsPanel, " ACTIVE RENTALS", "0", new Color(244, 164, 96), 470);
        createStatCard(statsPanel, " TOTAL REVENUE", "Rs. 0.00", new Color(255, 140, 0), 705);
        
        // Action Buttons Panel
        JPanel actionPanel = new JPanel();
        actionPanel.setLayout(null);
        actionPanel.setBackground(new Color(250, 245, 235));
        actionPanel.setBounds(30, 270, 940, 380);
        actionPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Management Actions",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(actionPanel);
        
        // Action Buttons
        int yPos = 50;
        int gap = 70;
        
        JButton btnFarmers = createActionButton("👨‍🌾 MANAGE FARMERS", 50, yPos, new Color(205, 133, 63));
        btnFarmers.addActionListener(e -> openFarmerManagement());
        actionPanel.add(btnFarmers);
        
        yPos += gap;
        JButton btnEquipment = createActionButton(" MANAGE EQUIPMENT", 50, yPos, new Color(210, 180, 140));
        btnEquipment.addActionListener(e -> openEquipmentManagement());
        actionPanel.add(btnEquipment);
        
        yPos += gap;
        JButton btnRentals = createActionButton(" MANAGE RENTALS", 50, yPos, new Color(244, 164, 96));
        btnRentals.addActionListener(e -> openRentalManagement());
        actionPanel.add(btnRentals);
        
        yPos += gap;
        JButton btnReport = createActionButton(" GENERATE REPORT", 50, yPos, new Color(184, 134, 11));
        btnReport.addActionListener(e -> generateReport());
        actionPanel.add(btnReport);
        
        yPos += gap;
        JButton btnRefresh = createActionButton(" REFRESH DATA", 50, yPos, new Color(139, 90, 43));
        btnRefresh.addActionListener(e -> loadStatistics());
        actionPanel.add(btnRefresh);
    }
    
    private void createStatCard(JPanel parent, String title, String value, Color color, int x) {
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBackground(color);
        card.setBounds(x, 0, 220, 140);
        card.setBorder(BorderFactory.createLineBorder(new Color(139, 90, 43), 2));
        
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(10, 20, 200, 30);
        card.add(lblTitle);
        
        JLabel lblValue = new JLabel(value, SwingConstants.CENTER);
        lblValue.setFont(new Font("Segoe UI", Font.BOLD, 32));
        lblValue.setForeground(Color.WHITE);
        lblValue.setBounds(10, 60, 200, 50);
        lblValue.setName(title); // For updating later
        card.add(lblValue);
        
        parent.add(card);
    }
    
    private JButton createActionButton(String text, int x, int y, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBounds(x, y, 840, 50);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        Color hoverColor = color.brighter();
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(hoverColor);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    private JButton createButton(String text, int x, int y, int width, int height, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBounds(x, y, width, height);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
    
    private void loadStatistics() {
        try {
            // Get statistics
            int totalFarmers = farmerDAO.getAllFarmers().size();
            int totalEquipment = equipmentDAO.getAllEquipment().size();
            int activeRentals = rentalDAO.getRentalCountByStatus("ACTIVE");
            double totalRevenue = rentalDAO.getTotalRevenue();
            
            // Update stat cards
            updateStatCard("👨‍🌾 TOTAL FARMERS", String.valueOf(totalFarmers));
            updateStatCard(" TOTAL EQUIPMENT", String.valueOf(totalEquipment));
            updateStatCard(" ACTIVE RENTALS", String.valueOf(activeRentals));
            updateStatCard(" TOTAL REVENUE", "Rs. " + String.format("%.2f", totalRevenue));
            
            System.out.println("✅ Dashboard statistics loaded!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading statistics: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateStatCard(String title, String value) {
        Component[] components = getContentPane().getComponents();
        for (Component comp : components) {
            if (comp instanceof JPanel) {
                updateStatCardRecursive((JPanel) comp, title, value);
            }
        }
    }
    
    private void updateStatCardRecursive(JPanel panel, String title, String value) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JPanel) {
                updateStatCardRecursive((JPanel) comp, title, value);
            } else if (comp instanceof JLabel) {
                JLabel label = (JLabel) comp;
                if (title.equals(label.getName())) {
                    label.setText(value);
                }
            }
        }
    }
    
    private void openFarmerManagement() {
        FarmerForm farmerForm = new FarmerForm();
        farmerForm.setVisible(true);
    }
    
    private void openEquipmentManagement() {
        EquipmentForm equipmentForm = new EquipmentForm();
        equipmentForm.setVisible(true);
    }
    
    private void openRentalManagement() {
        RentalForm rentalForm = new RentalForm();
        rentalForm.setVisible(true);
    }
    
    private void generateReport() {
        JOptionPane.showMessageDialog(this,
            "📊 Generating Revenue Report...\nPlease wait...",
            "Report Generation",
            JOptionPane.INFORMATION_MESSAGE);
        
        ReportController reportController = new ReportController();
        reportController.generateRevenueReport();
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        }
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new DashboardForm().setVisible(true));
    }
}