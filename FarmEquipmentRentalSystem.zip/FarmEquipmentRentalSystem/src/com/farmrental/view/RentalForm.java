package com.farmrental.view;

import com.farmrental.dao.*;
import com.farmrental.model.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Rental Management Form - MAIN TRANSACTION - FARM THEME
 */
public class RentalForm extends JFrame {
    
    private RentalDAO rentalDAO;
    private FarmerDAO farmerDAO;
    private EquipmentDAO equipmentDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblRentals;
    private JComboBox<String> cmbFarmer;
    private JComboBox<String> cmbEquipment;
    private JTextField txtRentalDate;
    private JTextField txtReturnDate;
    private JTextField txtTotalDays;
    private JTextField txtDailyRate;
    private JTextField txtTotalAmount;
    private JTextField txtDeposit;
    private JComboBox<String> cmbStatus;
    private JTextArea txtPurpose;
    private JTextArea txtNotes;
    
    private JButton btnAdd;
    private JButton btnComplete;
    private JButton btnCancel;
    private JButton btnClear;
    private JButton btnCalculate;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedRentalId = -1;
    
    public RentalForm() {
        rentalDAO = new RentalDAO();
        farmerDAO = new FarmerDAO();
        equipmentDAO = new EquipmentDAO();
        initComponents();
        loadRentals();
        loadFarmers();
        loadEquipment();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Rental Management - Main Transaction");
        setSize(1570, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 240, 230));
        
        // Header Panel - Sandy brown
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(244, 164, 96));
        headerPanel.setBounds(0, 0, 1550, 70);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel("📋 RENTAL MANAGEMENT - BOOKING SYSTEM");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 20, 750, 35);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setBounds(1400, 20, 120, 40);
        btnBack.setBackground(new Color(139, 90, 43));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // Left Panel - Rental Details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(null);
        detailsPanel.setBackground(new Color(250, 245, 235));
        detailsPanel.setBounds(20, 90, 550, 740);
        detailsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Rental Booking Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(detailsPanel);
        
        // Input Fields
        int yPos = 40;
        int gap = 60;
        
        addLabel(detailsPanel, "👨‍🌾 Farmer:", 20, yPos);
        cmbFarmer = new JComboBox<>();
        cmbFarmer.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbFarmer.setBackground(new Color(255, 250, 240));
        cmbFarmer.setBounds(20, yPos + 25, 510, 35);
        detailsPanel.add(cmbFarmer);
        
        yPos += gap;
        addLabel(detailsPanel, "🚜 Equipment:", 20, yPos);
        cmbEquipment = new JComboBox<>();
        cmbEquipment.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbEquipment.setBackground(new Color(255, 250, 240));
        cmbEquipment.setBounds(20, yPos + 25, 510, 35);
        cmbEquipment.addActionListener(e -> updateDailyRate());
        detailsPanel.add(cmbEquipment);
        
        yPos += gap;
        addLabel(detailsPanel, "📅 Rental Date (YYYY-MM-DD):", 20, yPos);
        txtRentalDate = addTextField(detailsPanel, 20, yPos + 25);
        txtRentalDate.setText(LocalDate.now().toString());
        
        yPos += gap;
        addLabel(detailsPanel, "📅 Return Date (YYYY-MM-DD):", 20, yPos);
        txtReturnDate = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Total Days:", 20, yPos);
        txtTotalDays = addTextField(detailsPanel, 20, yPos + 25);
        txtTotalDays.setEditable(false);
        txtTotalDays.setBackground(new Color(240, 235, 225));
        
        yPos += gap;
        addLabel(detailsPanel, "Daily Rate (Rs):", 20, yPos);
        txtDailyRate = addTextField(detailsPanel, 20, yPos + 25);
        txtDailyRate.setEditable(false);
        txtDailyRate.setBackground(new Color(240, 235, 225));
        
        yPos += gap;
        addLabel(detailsPanel, "💰 Total Amount (Rs):", 20, yPos);
        txtTotalAmount = addTextField(detailsPanel, 20, yPos + 25);
        txtTotalAmount.setEditable(false);
        txtTotalAmount.setBackground(new Color(255, 248, 220));
        txtTotalAmount.setFont(new Font("Segoe UI", Font.BOLD, 15));
        txtTotalAmount.setForeground(new Color(139, 90, 43));
        
        yPos += gap;
        addLabel(detailsPanel, "Deposit Amount (Rs):", 20, yPos);
        txtDeposit = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Status:", 20, yPos);
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "COMPLETED", "CANCELLED"});
        cmbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbStatus.setBackground(new Color(255, 250, 240));
        cmbStatus.setBounds(20, yPos + 25, 510, 35);
        detailsPanel.add(cmbStatus);
        
        yPos += gap;
        addLabel(detailsPanel, "Purpose:", 20, yPos);
        txtPurpose = new JTextArea();
        txtPurpose.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtPurpose.setBackground(new Color(255, 250, 240));
        txtPurpose.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        txtPurpose.setLineWrap(true);
        txtPurpose.setWrapStyleWord(true);
        JScrollPane scrollPurpose = new JScrollPane(txtPurpose);
        scrollPurpose.setBounds(20, yPos + 25, 510, 50);
        detailsPanel.add(scrollPurpose);
        
        // Action Buttons
        yPos += 85;
        btnCalculate = createButton("CALCULATE", 20, yPos, new Color(52, 152, 219), 120);
        btnCalculate.addActionListener(e -> calculateTotal());
        detailsPanel.add(btnCalculate);
        
        btnAdd = createButton("🌾 BOOK", 150, yPos, new Color(34, 139, 34), 120);
        btnAdd.addActionListener(e -> addRental());
        detailsPanel.add(btnAdd);
        
        btnComplete = createButton("COMPLETE", 280, yPos, new Color(255, 140, 0), 120);
        btnComplete.addActionListener(e -> completeRental());
        detailsPanel.add(btnComplete);
        
        btnClear = createButton("CLEAR", 410, yPos, new Color(139, 90, 43), 120);
        btnClear.addActionListener(e -> clearFields());
        detailsPanel.add(btnClear);
        
        // Right Panel - Rental Table
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(new Color(250, 245, 235));
        tablePanel.setBounds(590, 90, 940, 7400);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Rental Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(tablePanel);
        
        // Filter Panel
        JLabel lblFilter = new JLabel("Filter:");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblFilter.setForeground(new Color(101, 67, 33));
        lblFilter.setBounds(20, 35, 70, 35);
        tablePanel.add(lblFilter);
        
        JButton btnShowActive = createButton("ACTIVE", 90, 35, new Color(34, 139, 34), 100);
        btnShowActive.addActionListener(e -> loadActiveRentals());
        tablePanel.add(btnShowActive);
        
        JButton btnShowAll = createButton("ALL", 200, 35, new Color(52, 152, 219), 100);
        btnShowAll.addActionListener(e -> loadRentals());
        tablePanel.add(btnShowAll);
        
        btnRefresh = createButton("REFRESH", 310, 35, new Color(255, 140, 0), 100);
        btnRefresh.addActionListener(e -> loadRentals());
        tablePanel.add(btnRefresh);
        
        btnCancel = createButton("CANCEL", 420, 35, new Color(178, 34, 34), 100);
        btnCancel.addActionListener(e -> cancelRental());
        tablePanel.add(btnCancel);
        
        // Table
        String[] columns = {"ID", "Farmer", "Equipment", "Rental Date", "Return Date", "Days", "Amount", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblRentals = new JTable(tableModel);
        tblRentals.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tblRentals.setRowHeight(28);
        tblRentals.setBackground(new Color(255, 250, 240));
        tblRentals.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tblRentals.getTableHeader().setBackground(new Color(244, 164, 96));
        tblRentals.getTableHeader().setForeground(Color.WHITE);
        tblRentals.setSelectionBackground(new Color(255, 140, 0));
        tblRentals.setSelectionForeground(Color.WHITE);
        
        // Table selection listener
        tblRentals.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedRental();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblRentals);
        scrollPane.setBounds(20, 90, 900, 630);
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(101, 67, 33));
        label.setBounds(x, y, 350, 25);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBackground(new Color(255, 250, 240));
        field.setBounds(x, y, 510, 35);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 35);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
    
    // Load farmers into combo box
    private void loadFarmers() {
        try {
            cmbFarmer.removeAllItems();
            List<Farmer> farmers = farmerDAO.getAllFarmers();
            for (Farmer farmer : farmers) {
                cmbFarmer.addItem(farmer.getFarmerId() + " - " + farmer.getFullName() + 
                                 " (" + farmer.getFarmLocation() + ")");
            }
        } catch (SQLException e) {
            showError("Error loading farmers: " + e.getMessage());
        }
    }
    
    // Load available equipment into combo box
    private void loadEquipment() {
        try {
            cmbEquipment.removeAllItems();
            List<Equipment> equipmentList = equipmentDAO.getAvailableEquipment();
            for (Equipment equipment : equipmentList) {
                cmbEquipment.addItem(equipment.getEquipmentId() + " - " + 
                                    equipment.getCategoryName() + " - " +
                                    equipment.getFullName() + 
                                    " (" + equipment.getEquipmentNumber() + ") - Rs." + 
                                    equipment.getDailyRate());
            }
        } catch (SQLException e) {
            showError("Error loading equipment: " + e.getMessage());
        }
    }
    
    // Update daily rate when equipment is selected
    private void updateDailyRate() {
        String selected = (String) cmbEquipment.getSelectedItem();
        if (selected != null) {
            try {
                int equipmentId = Integer.parseInt(selected.split(" - ")[0]);
                Equipment equipment = equipmentDAO.getEquipmentById(equipmentId);
                if (equipment != null) {
                    txtDailyRate.setText(String.format("%.2f", equipment.getDailyRate()));
                }
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    // Calculate total amount
    private void calculateTotal() {
        try {
            LocalDate rentalDate = LocalDate.parse(txtRentalDate.getText().trim());
            LocalDate returnDate = LocalDate.parse(txtReturnDate.getText().trim());
            
            if (returnDate.isBefore(rentalDate)) {
                showWarning("Return date cannot be before rental date!");
                return;
            }
            
            long days = ChronoUnit.DAYS.between(rentalDate, returnDate);
            if (days == 0) days = 1; // Minimum 1 day
            
            double dailyRate = Double.parseDouble(txtDailyRate.getText().trim());
            double totalAmount = days * dailyRate;
            
            txtTotalDays.setText(String.valueOf(days));
            txtTotalAmount.setText(String.format("%.2f", totalAmount));
            
            showInfo("✅ Calculation complete!\n\nTotal Days: " + days + 
                    "\nTotal Amount: Rs." + String.format("%.2f", totalAmount));
            
        } catch (Exception e) {
            showError("Error calculating total: " + e.getMessage() + 
                     "\n\nPlease check date format (YYYY-MM-DD)");
        }
    }
    
    // Load all rentals
    private void loadRentals() {
        try {
            tableModel.setRowCount(0);
            List<Rental> rentals = rentalDAO.getAllRentals();
            
            for (Rental rental : rentals) {
                Object[] row = {
                    rental.getRentalId(),
                    rental.getFarmerName(),
                    rental.getEquipmentName(),
                    rental.getRentalDate(),
                    rental.getReturnDate(),
                    rental.getTotalDays(),
                    "Rs. " + String.format("%.2f", rental.getTotalAmount()),
                    rental.getStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading rentals: " + e.getMessage());
        }
    }
    
    // Load active rentals only
    private void loadActiveRentals() {
        try {
            tableModel.setRowCount(0);
            List<Rental> rentals = rentalDAO.getActiveRentals();
            
            for (Rental rental : rentals) {
                Object[] row = {
                    rental.getRentalId(),
                    rental.getFarmerName(),
                    rental.getEquipmentName(),
                    rental.getRentalDate(),
                    rental.getReturnDate(),
                    rental.getTotalDays(),
                    "Rs. " + String.format("%.2f", rental.getTotalAmount()),
                    rental.getStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading active rentals: " + e.getMessage());
        }
    }
    
    // Load selected rental into fields
    private void loadSelectedRental() {
        int selectedRow = tblRentals.getSelectedRow();
        if (selectedRow >= 0) {
            selectedRentalId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                Rental rental = rentalDAO.getRentalById(selectedRentalId);
                if (rental != null) {
                    // Set combo boxes
                    cmbFarmer.setSelectedItem(rental.getFarmerId() + " - " + rental.getFarmerName());
                    
                    txtRentalDate.setText(rental.getRentalDate().toString());
                    txtReturnDate.setText(rental.getReturnDate().toString());
                    txtTotalDays.setText(String.valueOf(rental.getTotalDays()));
                    txtDailyRate.setText(String.format("%.2f", rental.getDailyRate()));
                    txtTotalAmount.setText(String.format("%.2f", rental.getTotalAmount()));
                    txtDeposit.setText(String.format("%.2f", rental.getDepositAmount()));
                    txtPurpose.setText(rental.getPurpose());
                }
            } catch (SQLException e) {
                showError("Error loading rental details: " + e.getMessage());
            }
        }
    }
    
    // Add new rental
    private void addRental() {
        if (!validateInputs()) return;
        
        try {
            // Get farmer ID
            String farmerStr = (String) cmbFarmer.getSelectedItem();
            int farmerId = Integer.parseInt(farmerStr.split(" - ")[0]);
            
            // Get equipment ID
            String equipmentStr = (String) cmbEquipment.getSelectedItem();
            int equipmentId = Integer.parseInt(equipmentStr.split(" - ")[0]);
            
            Rental rental = new Rental();
            rental.setFarmerId(farmerId);
            rental.setEquipmentId(equipmentId);
            rental.setRentalDate(Date.valueOf(txtRentalDate.getText().trim()));
            rental.setReturnDate(Date.valueOf(txtReturnDate.getText().trim()));
            rental.setTotalDays(Integer.parseInt(txtTotalDays.getText().trim()));
            rental.setDailyRate(Double.parseDouble(txtDailyRate.getText().trim()));
            rental.setTotalAmount(Double.parseDouble(txtTotalAmount.getText().trim()));
            rental.setDepositAmount(Double.parseDouble(txtDeposit.getText().trim()));
            rental.setStatus("ACTIVE");
            rental.setPurpose(txtPurpose.getText().trim());
            
            boolean success = rentalDAO.addRental(rental);
            
            if (success) {
                // Update equipment status to RENTED
                equipmentDAO.updateEquipmentStatus(equipmentId, "RENTED");
                
                showSuccess("🌾 Rental booked successfully!\n\n" +
                           "Farmer: " + farmerStr.split(" - ")[1] + "\n" +
                           "Equipment: " + equipmentStr.split(" - ")[1] + "\n" +
                           "Total: Rs." + txtTotalAmount.getText());
                
                loadRentals();
                loadEquipment(); // Refresh available equipment
                clearFields();
            } else {
                showError("Failed to create rental!");
            }
            
        } catch (SQLException e) {
            showError("Error creating rental: " + e.getMessage());
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    // Complete rental (return equipment)
    private void completeRental() {
        if (selectedRentalId == -1) {
            showWarning("Please select a rental to complete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Complete this rental and mark equipment as returned?",
            "Confirm Complete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Get rental to get equipment ID
                Rental rental = rentalDAO.getRentalById(selectedRentalId);
                
                // Complete rental
                boolean success = rentalDAO.completeRental(selectedRentalId, Date.valueOf(LocalDate.now()));
                
                if (success) {
                    // Update equipment status to AVAILABLE
                    equipmentDAO.updateEquipmentStatus(rental.getEquipmentId(), "AVAILABLE");
                    
                    showSuccess("✅ Rental completed successfully!\nEquipment is now available for rent.");
                    loadRentals();
                    loadEquipment();
                    clearFields();
                } else {
                    showError("Failed to complete rental!");
                }
                
            } catch (SQLException e) {
                showError("Error completing rental: " + e.getMessage());
            }
        }
    }
    
    // Cancel rental
    private void cancelRental() {
        if (selectedRentalId == -1) {
            showWarning("Please select a rental to cancel!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to cancel this rental?",
            "Confirm Cancel",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Get rental to get equipment ID
                Rental rental = rentalDAO.getRentalById(selectedRentalId);
                
                // Cancel rental
                boolean success = rentalDAO.cancelRental(selectedRentalId);
                
                if (success) {
                    // Update equipment status to AVAILABLE
                    equipmentDAO.updateEquipmentStatus(rental.getEquipmentId(), "AVAILABLE");
                    
                    showSuccess("✅ Rental cancelled successfully!");
                    loadRentals();
                    loadEquipment();
                    clearFields();
                } else {
                    showError("Failed to cancel rental!");
                }
                
            } catch (SQLException e) {
                showError("Error cancelling rental: " + e.getMessage());
            }
        }
    }
    
    // Clear all fields
    private void clearFields() {
        if (cmbFarmer.getItemCount() > 0) cmbFarmer.setSelectedIndex(0);
        if (cmbEquipment.getItemCount() > 0) cmbEquipment.setSelectedIndex(0);
        txtRentalDate.setText(LocalDate.now().toString());
        txtReturnDate.setText("");
        txtTotalDays.setText("");
        txtDailyRate.setText("");
        txtTotalAmount.setText("");
        txtDeposit.setText("");
        txtPurpose.setText("");
        selectedRentalId = -1;
        tblRentals.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        if (cmbFarmer.getSelectedItem() == null) {
            showWarning("Please select a farmer!");
            return false;
        }
        
        if (cmbEquipment.getSelectedItem() == null) {
            showWarning("Please select equipment!");
            return false;
        }
        
        if (txtTotalDays.getText().trim().isEmpty()) {
            showWarning("Please calculate total first!");
            btnCalculate.requestFocus();
            return false;
        }
        
        try {
            double deposit = Double.parseDouble(txtDeposit.getText().trim());
            if (deposit < 0) {
                showWarning("Deposit cannot be negative!");
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid deposit amount!");
            txtDeposit.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Main for testing
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new RentalForm().setVisible(true));
    }
}