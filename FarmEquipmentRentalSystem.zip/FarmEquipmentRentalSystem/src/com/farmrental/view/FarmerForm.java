package com.farmrental.view;

import com.farmrental.dao.FarmerDAO;
import com.farmrental.model.Farmer;
import com.farmrental.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Farmer Management Form - FARM THEME
 */
public class FarmerForm extends JFrame {
    
    private FarmerDAO farmerDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblFarmers;
    private JTextField txtFirstName;
    private JTextField txtLastName;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JTextField txtNIC;
    private JTextField txtFarmLocation;
    private JTextField txtFarmSize;
    private JTextArea txtAddress;
    private JTextField txtSearch;
    
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JButton btnSearch;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedFarmerId = -1;
    
    public FarmerForm() {
        farmerDAO = new FarmerDAO();
        initComponents();
        loadFarmers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Farmer Management");
        setSize(1350, 780);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 240, 230));
        
        // Header Panel - Brown
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(139, 90, 43));
        headerPanel.setBounds(0, 0, 1350, 70);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel("👨‍🌾 FARMER MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 20, 450, 35);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setBounds(1200, 20, 120, 40);
        btnBack.setBackground(new Color(205, 133, 63));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // Left Panel - Farmer Details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(null);
        detailsPanel.setBackground(new Color(250, 245, 235));
        detailsPanel.setBounds(20, 90, 450, 660);
        detailsPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Farmer Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(detailsPanel);
        
        // Input Fields
        int yPos = 40;
        int gap = 67;
        
        addLabel(detailsPanel, "First Name:", 20, yPos);
        txtFirstName = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Last Name:", 20, yPos);
        txtLastName = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Email:", 20, yPos);
        txtEmail = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Phone:", 20, yPos);
        txtPhone = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "NIC:", 20, yPos);
        txtNIC = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Farm Location:", 20, yPos);
        txtFarmLocation = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Farm Size (acres):", 20, yPos);
        txtFarmSize = addTextField(detailsPanel, 20, yPos + 25);
        
        yPos += gap;
        addLabel(detailsPanel, "Address:", 20, yPos);
        txtAddress = new JTextArea();
        txtAddress.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtAddress.setBackground(new Color(255, 250, 240));
        txtAddress.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        txtAddress.setLineWrap(true);
        txtAddress.setWrapStyleWord(true);
        JScrollPane scrollAddress = new JScrollPane(txtAddress);
        scrollAddress.setBounds(20, yPos + 25, 410, 60);
        detailsPanel.add(scrollAddress);
        
        // Action Buttons
        yPos += 95;
        btnAdd = createButton("ADD", 20, yPos, new Color(34, 139, 34));
        btnAdd.addActionListener(e -> addFarmer());
        detailsPanel.add(btnAdd);
        
        btnUpdate = createButton("UPDATE", 115, yPos, new Color(255, 140, 0));
        btnUpdate.addActionListener(e -> updateFarmer());
        detailsPanel.add(btnUpdate);
        
        btnDelete = createButton("DELETE", 210, yPos, new Color(178, 34, 34));
        btnDelete.addActionListener(e -> deleteFarmer());
        detailsPanel.add(btnDelete);
        
        btnClear = createButton("CLEAR", 305, yPos, new Color(139, 90, 43));
        btnClear.addActionListener(e -> clearFields());
        detailsPanel.add(btnClear);
        
        // Right Panel - Farmer Table
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(new Color(250, 245, 235));
        tablePanel.setBounds(490, 90, 840, 660);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(139, 90, 43), 2),
            "Farmer List",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 16),
            new Color(101, 67, 33)
        ));
        add(tablePanel);
        
        // Search Panel
        JLabel lblSearch = new JLabel("🔍 Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSearch.setForeground(new Color(101, 67, 33));
        lblSearch.setBounds(20, 35, 100, 35);
        tablePanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBackground(new Color(255, 250, 240));
        txtSearch.setBounds(120, 35, 300, 35);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        tablePanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 440, 35, new Color(255, 140, 0));
        btnSearch.addActionListener(e -> searchFarmers());
        tablePanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 545, 35, new Color(34, 139, 34));
        btnRefresh.addActionListener(e -> loadFarmers());
        tablePanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "First Name", "Last Name", "Email", "Phone", "NIC", "Farm Location", "Farm Size"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblFarmers = new JTable(tableModel);
        tblFarmers.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tblFarmers.setRowHeight(28);
        tblFarmers.setBackground(new Color(255, 250, 240));
        tblFarmers.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tblFarmers.getTableHeader().setBackground(new Color(205, 133, 63));
        tblFarmers.getTableHeader().setForeground(Color.WHITE);
        tblFarmers.setSelectionBackground(new Color(255, 140, 0));
        tblFarmers.setSelectionForeground(Color.WHITE);
        
        // Table selection listener
        tblFarmers.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedFarmer();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblFarmers);
        scrollPane.setBounds(20, 90, 800, 550);
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(new Color(101, 67, 33));
        label.setBounds(x, y, 200, 25);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBackground(new Color(255, 250, 240));
        field.setBounds(x, y, 410, 38);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(205, 133, 63), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, 90, 35);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
    
    // Load all farmers
    private void loadFarmers() {
        try {
            tableModel.setRowCount(0);
            List<Farmer> farmers = farmerDAO.getAllFarmers();
            
            for (Farmer farmer : farmers) {
                Object[] row = {
                    farmer.getFarmerId(),
                    farmer.getFirstName(),
                    farmer.getLastName(),
                    farmer.getEmail(),
                    farmer.getPhone(),
                    farmer.getNic(),
                    farmer.getFarmLocation(),
                    farmer.getFarmSize() + " acres"
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading farmers: " + e.getMessage());
        }
    }
    
    // Load selected farmer into fields
    private void loadSelectedFarmer() {
        int selectedRow = tblFarmers.getSelectedRow();
        if (selectedRow >= 0) {
            selectedFarmerId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                Farmer farmer = farmerDAO.getFarmerById(selectedFarmerId);
                if (farmer != null) {
                    txtFirstName.setText(farmer.getFirstName());
                    txtLastName.setText(farmer.getLastName());
                    txtEmail.setText(farmer.getEmail());
                    txtPhone.setText(farmer.getPhone());
                    txtNIC.setText(farmer.getNic());
                    txtFarmLocation.setText(farmer.getFarmLocation());
                    txtFarmSize.setText(String.valueOf(farmer.getFarmSize()));
                    txtAddress.setText(farmer.getAddress());
                }
            } catch (SQLException e) {
                showError("Error loading farmer details: " + e.getMessage());
            }
        }
    }
    
    // Add farmer
    private void addFarmer() {
        if (!validateInputs()) return;
        
        try {
            Farmer farmer = new Farmer();
            farmer.setFirstName(txtFirstName.getText().trim());
            farmer.setLastName(txtLastName.getText().trim());
            farmer.setEmail(txtEmail.getText().trim());
            farmer.setPhone(txtPhone.getText().trim());
            farmer.setNic(txtNIC.getText().trim());
            farmer.setFarmLocation(txtFarmLocation.getText().trim());
            farmer.setFarmSize(Double.parseDouble(txtFarmSize.getText().trim()));
            farmer.setAddress(txtAddress.getText().trim());
            
            boolean success = farmerDAO.addFarmer(farmer);
            
            if (success) {
                showSuccess("✅ Farmer added successfully!");
                loadFarmers();
                clearFields();
            } else {
                showError("Failed to add farmer!");
            }
            
        } catch (SQLException e) {
            showError("Error adding farmer: " + e.getMessage());
        }
    }
    
    // Update farmer
    private void updateFarmer() {
        if (selectedFarmerId == -1) {
            showWarning("Please select a farmer to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            Farmer farmer = new Farmer();
            farmer.setFarmerId(selectedFarmerId);
            farmer.setFirstName(txtFirstName.getText().trim());
            farmer.setLastName(txtLastName.getText().trim());
            farmer.setEmail(txtEmail.getText().trim());
            farmer.setPhone(txtPhone.getText().trim());
            farmer.setNic(txtNIC.getText().trim());
            farmer.setFarmLocation(txtFarmLocation.getText().trim());
            farmer.setFarmSize(Double.parseDouble(txtFarmSize.getText().trim()));
            farmer.setAddress(txtAddress.getText().trim());
            
            boolean success = farmerDAO.updateFarmer(farmer);
            
            if (success) {
                showSuccess("✅ Farmer updated successfully!");
                loadFarmers();
                clearFields();
            } else {
                showError("Failed to update farmer!");
            }
            
        } catch (SQLException e) {
            showError("Error updating farmer: " + e.getMessage());
        }
    }
    
    // Delete farmer
    private void deleteFarmer() {
        if (selectedFarmerId == -1) {
            showWarning("Please select a farmer to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this farmer?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = farmerDAO.deleteFarmer(selectedFarmerId);
                
                if (success) {
                    showSuccess("✅ Farmer deleted successfully!");
                    loadFarmers();
                    clearFields();
                } else {
                    showError("Failed to delete farmer!");
                }
                
            } catch (SQLException e) {
                showError("Error deleting farmer: " + e.getMessage());
            }
        }
    }
    
    // Search farmers
    private void searchFarmers() {
        String searchTerm = txtSearch.getText().trim();
        
        if (searchTerm.isEmpty()) {
            loadFarmers();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<Farmer> farmers = farmerDAO.searchFarmers(searchTerm);
            
            for (Farmer farmer : farmers) {
                Object[] row = {
                    farmer.getFarmerId(),
                    farmer.getFirstName(),
                    farmer.getLastName(),
                    farmer.getEmail(),
                    farmer.getPhone(),
                    farmer.getNic(),
                    farmer.getFarmLocation(),
                    farmer.getFarmSize() + " acres"
                };
                tableModel.addRow(row);
            }
            
            if (farmers.isEmpty()) {
                showInfo("No farmers found matching: " + searchTerm);
            }
            
        } catch (SQLException e) {
            showError("Error searching farmers: " + e.getMessage());
        }
    }
    
    // Clear all fields
    private void clearFields() {
        txtFirstName.setText("");
        txtLastName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtNIC.setText("");
        txtFarmLocation.setText("");
        txtFarmSize.setText("");
        txtAddress.setText("");
        txtSearch.setText("");
        selectedFarmerId = -1;
        tblFarmers.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        String firstName = txtFirstName.getText().trim();
        String lastName = txtLastName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String nic = txtNIC.getText().trim();
        String farmSize = txtFarmSize.getText().trim();
        
        if (Validator.isEmpty(firstName)) {
            showWarning("First name is required!");
            txtFirstName.requestFocus();
            return false;
        }
        
        if (Validator.isEmpty(lastName)) {
            showWarning("Last name is required!");
            txtLastName.requestFocus();
            return false;
        }
        
        if (!Validator.isValidEmail(email)) {
            showWarning("Invalid email format!");
            txtEmail.requestFocus();
            return false;
        }
        
        if (!Validator.isValidPhone(phone)) {
            showWarning("Invalid phone number! (10 digits starting with 0)");
            txtPhone.requestFocus();
            return false;
        }
        
        if (!Validator.isValidNIC(nic)) {
            showWarning("Invalid NIC format!");
            txtNIC.requestFocus();
            return false;
        }
        
        try {
            double size = Double.parseDouble(farmSize);
            if (size <= 0) {
                showWarning("Farm size must be positive!");
                txtFarmSize.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid farm size!");
            txtFarmSize.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Main for testing
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new FarmerForm().setVisible(true));
    }
}