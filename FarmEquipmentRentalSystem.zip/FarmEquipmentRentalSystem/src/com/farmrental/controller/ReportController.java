package com.farmrental.controller;

import com.farmrental.dao.DatabaseConnection;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 * Controller for generating Jasper Reports
 */
public class ReportController {
    
    private Connection connection;
    
    public ReportController() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    /**
     * Generate Revenue Report by Equipment Category
     * Uses 3 tables: rentals, equipment, equipment_categories
     */
    public void generateRevenueReport() {
        try {
            // SQL Query - Uses 3 tables with JOINs
            String query = 
                "SELECT " +
                "    ec.category_name AS category, " +
                "    ec.daily_rate AS rate, " +
                "    COUNT(r.rental_id) AS total_rentals, " +
                "    SUM(r.total_amount) AS total_revenue, " +
                "    AVG(r.total_amount) AS avg_revenue, " +
                "    SUM(r.total_days) AS total_days " +
                "FROM rentals r " +
                "JOIN equipment e ON r.equipment_id = e.equipment_id " +
                "JOIN equipment_categories ec ON e.category_id = ec.category_id " +
                "WHERE r.status = 'COMPLETED' " +
                "GROUP BY ec.category_id, ec.category_name, ec.daily_rate " +
                "ORDER BY total_revenue DESC";
            
            // Create JasperDesign programmatically
            JasperReport jasperReport = createReportDesign();
            
            // Parameters
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ReportTitle", "REVENUE ANALYSIS BY EQUIPMENT CATEGORY");
            parameters.put("GeneratedBy", "Farm Equipment Rental System");
            
            // Fill report with data
            JasperPrint jasperPrint = JasperFillManager.fillReport(
                jasperReport, 
                parameters, 
                connection
            );
            
            // Display report
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setVisible(true);
            
            System.out.println("✅ Report generated successfully!");
            
        } catch (JRException e) {
            System.err.println("❌ Report generation failed: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Report generation failed: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Create Jasper Report Design Programmatically
     */
    private JasperReport createReportDesign() throws JRException {
        // Create a simple report design using JasperReports API
        
        String jrxml = 
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<jasperReport xmlns=\"http://jasperreports.sourceforge.net/jasperreports\"\n" +
            "              xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "              xsi:schemaLocation=\"http://jasperreports.sourceforge.net/jasperreports\n" +
            "              http://jasperreports.sourceforge.net/xsd/jasperreport.xsd\"\n" +
            "              name=\"RevenueReport\" pageWidth=\"595\" pageHeight=\"842\"\n" +
            "              columnWidth=\"535\" leftMargin=\"20\" rightMargin=\"20\"\n" +
            "              topMargin=\"20\" bottomMargin=\"20\">\n" +
            "    \n" +
            "    <parameter name=\"ReportTitle\" class=\"java.lang.String\"/>\n" +
            "    <parameter name=\"GeneratedBy\" class=\"java.lang.String\"/>\n" +
            "    \n" +
            "    <queryString>\n" +
            "        <![CDATA[\n" +
            "            SELECT \n" +
            "                ec.category_name AS category,\n" +
            "                ec.daily_rate AS rate,\n" +
            "                COUNT(r.rental_id) AS total_rentals,\n" +
            "                SUM(r.total_amount) AS total_revenue,\n" +
            "                AVG(r.total_amount) AS avg_revenue,\n" +
            "                SUM(r.total_days) AS total_days\n" +
            "            FROM rentals r\n" +
            "            JOIN equipment e ON r.equipment_id = e.equipment_id\n" +
            "            JOIN equipment_categories ec ON e.category_id = ec.category_id\n" +
            "            WHERE r.status = 'COMPLETED'\n" +
            "            GROUP BY ec.category_id, ec.category_name, ec.daily_rate\n" +
            "            ORDER BY total_revenue DESC\n" +
            "        ]]>\n" +
            "    </queryString>\n" +
            "    \n" +
            "    <field name=\"category\" class=\"java.lang.String\"/>\n" +
            "    <field name=\"rate\" class=\"java.math.BigDecimal\"/>\n" +
            "    <field name=\"total_rentals\" class=\"java.lang.Long\"/>\n" +
            "    <field name=\"total_revenue\" class=\"java.math.BigDecimal\"/>\n" +
            "    <field name=\"avg_revenue\" class=\"java.math.BigDecimal\"/>\n" +
            "    <field name=\"total_days\" class=\"java.math.BigDecimal\"/>\n" +
            "    \n" +
            "    <variable name=\"total_revenue_sum\" class=\"java.math.BigDecimal\" calculation=\"Sum\">\n" +
            "        <variableExpression><![CDATA[$F{total_revenue}]]></variableExpression>\n" +
            "    </variable>\n" +
            "    \n" +
            "    <title>\n" +
            "        <band height=\"80\">\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"0\" y=\"10\" width=\"535\" height=\"30\"/>\n" +
            "                <textElement textAlignment=\"Center\">\n" +
            "                    <font size=\"18\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[FARM EQUIPMENT RENTAL SYSTEM]]></text>\n" +
            "            </staticText>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"0\" y=\"45\" width=\"535\" height=\"25\"/>\n" +
            "                <textElement textAlignment=\"Center\">\n" +
            "                    <font size=\"14\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$P{ReportTitle}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "        </band>\n" +
            "    </title>\n" +
            "    \n" +
            "    <columnHeader>\n" +
            "        <band height=\"30\">\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"0\" y=\"0\" width=\"120\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"10\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Category]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"120\" y=\"0\" width=\"80\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"10\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Daily Rate]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"200\" y=\"0\" width=\"70\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"10\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Rentals]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"270\" y=\"0\" width=\"90\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"10\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Total Days]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"360\" y=\"0\" width=\"90\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"10\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Avg Revenue]]></text>\n" +
            "            </staticText>\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"450\" y=\"0\" width=\"85\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"10\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[Total Revenue]]></text>\n" +
            "            </staticText>\n" +
            "        </band>\n" +
            "    </columnHeader>\n" +
            "    \n" +
            "    <detail>\n" +
            "        <band height=\"25\">\n" +
            "            <textField>\n" +
            "                <reportElement x=\"0\" y=\"0\" width=\"120\" height=\"25\"/>\n" +
            "                <box leftPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement verticalAlignment=\"Middle\"/>\n" +
            "                <textFieldExpression><![CDATA[$F{category}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField pattern=\"#,##0.00\">\n" +
            "                <reportElement x=\"120\" y=\"0\" width=\"80\" height=\"25\"/>\n" +
            "                <box leftPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement verticalAlignment=\"Middle\"/>\n" +
            "                <textFieldExpression><![CDATA[$F{rate}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"200\" y=\"0\" width=\"70\" height=\"25\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\"/>\n" +
            "                <textFieldExpression><![CDATA[$F{total_rentals}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField>\n" +
            "                <reportElement x=\"270\" y=\"0\" width=\"90\" height=\"25\"/>\n" +
            "                <box><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\"/>\n" +
            "                <textFieldExpression><![CDATA[$F{total_days}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField pattern=\"#,##0.00\">\n" +
            "                <reportElement x=\"360\" y=\"0\" width=\"90\" height=\"25\"/>\n" +
            "                <box rightPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Right\" verticalAlignment=\"Middle\"/>\n" +
            "                <textFieldExpression><![CDATA[$F{avg_revenue}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "            <textField pattern=\"#,##0.00\">\n" +
            "                <reportElement x=\"450\" y=\"0\" width=\"85\" height=\"25\"/>\n" +
            "                <box rightPadding=\"5\"><pen lineWidth=\"1.0\"/></box>\n" +
            "                <textElement textAlignment=\"Right\" verticalAlignment=\"Middle\">\n" +
            "                    <font isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$F{total_revenue}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "        </band>\n" +
            "    </detail>\n" +
            "    \n" +
            "    <summary>\n" +
            "        <band height=\"50\">\n" +
            "            <staticText>\n" +
            "                <reportElement x=\"270\" y=\"10\" width=\"180\" height=\"30\"/>\n" +
            "                <box><pen lineWidth=\"2.0\"/></box>\n" +
            "                <textElement textAlignment=\"Center\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"12\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <text><![CDATA[GRAND TOTAL (Rs):]]></text>\n" +
            "            </staticText>\n" +
            "            <textField pattern=\"#,##0.00\">\n" +
            "                <reportElement x=\"450\" y=\"10\" width=\"85\" height=\"30\"/>\n" +
            "                <box rightPadding=\"5\"><pen lineWidth=\"2.0\"/></box>\n" +
            "                <textElement textAlignment=\"Right\" verticalAlignment=\"Middle\">\n" +
            "                    <font size=\"12\" isBold=\"true\"/>\n" +
            "                </textElement>\n" +
            "                <textFieldExpression><![CDATA[$V{total_revenue_sum}]]></textFieldExpression>\n" +
            "            </textField>\n" +
            "        </band>\n" +
            "    </summary>\n" +
            "</jasperReport>";
        
        // Compile the report
        return JasperCompileManager.compileReport(
            new java.io.ByteArrayInputStream(jrxml.getBytes())
        );
    }
}