package com.farmrental;

import com.farmrental.view.LoginForm;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Main Application Entry Point
 * Farm Equipment Rental Management System
 * 
 * @author NIBM Student - HDSE Batch 25.2
 * @version 1.0
 */
public class Main {
    
    public static void main(String[] args) {
        // Set system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Launch application
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Show login form
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true);
                
                System.out.println("========================================");
                System.out.println("🚜 FARM EQUIPMENT RENTAL SYSTEM");
                System.out.println("========================================");
                System.out.println("✅ System started successfully!");
                System.out.println("📋 Default Login Credentials:");
                System.out.println("   Username: admin");
                System.out.println("   Password: admin123");
                System.out.println("========================================");
            }
        });
    }
}