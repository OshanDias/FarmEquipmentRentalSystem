package com.farmrental.dao;

import com.farmrental.model.Rental;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for Rental entity
 * Handles all database operations for rentals (MAIN TRANSACTION)
 */
public class RentalDAO {
    
    private Connection connection;
    
    public RentalDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new rental
    public boolean addRental(Rental rental) throws SQLException {
        String query = "INSERT INTO rentals (farmer_id, equipment_id, rental_date, return_date, " +
                       "total_days, daily_rate, total_amount, deposit_amount, status, purpose, notes) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, rental.getFarmerId());
            pstmt.setInt(2, rental.getEquipmentId());
            pstmt.setDate(3, rental.getRentalDate());
            pstmt.setDate(4, rental.getReturnDate());
            pstmt.setInt(5, rental.getTotalDays());
            pstmt.setDouble(6, rental.getDailyRate());
            pstmt.setDouble(7, rental.getTotalAmount());
            pstmt.setDouble(8, rental.getDepositAmount());
            pstmt.setString(9, rental.getStatus());
            pstmt.setString(10, rental.getPurpose());
            pstmt.setString(11, rental.getNotes());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error adding rental: " + e.getMessage());
            throw e;
        }
    }
    
    // READ - Get rental by ID (with farmer and equipment info)
    public Rental getRentalById(int rentalId) throws SQLException {
        String query = "SELECT r.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "e.equipment_number, " +
                       "CONCAT(e.brand, ' ', e.model) as equipment_name " +
                       "FROM rentals r " +
                       "JOIN farmers f ON r.farmer_id = f.farmer_id " +
                       "JOIN equipment e ON r.equipment_id = e.equipment_id " +
                       "WHERE r.rental_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, rentalId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractRentalFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving rental: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    // READ - Get all rentals (with farmer and equipment info)
    public List<Rental> getAllRentals() throws SQLException {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT r.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "e.equipment_number, " +
                       "CONCAT(e.brand, ' ', e.model) as equipment_name " +
                       "FROM rentals r " +
                       "JOIN farmers f ON r.farmer_id = f.farmer_id " +
                       "JOIN equipment e ON r.equipment_id = e.equipment_id " +
                       "ORDER BY r.rental_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                rentals.add(extractRentalFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving rentals: " + e.getMessage());
            throw e;
        }
        return rentals;
    }
    
    // READ - Get active rentals only
    public List<Rental> getActiveRentals() throws SQLException {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT r.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "e.equipment_number, " +
                       "CONCAT(e.brand, ' ', e.model) as equipment_name " +
                       "FROM rentals r " +
                       "JOIN farmers f ON r.farmer_id = f.farmer_id " +
                       "JOIN equipment e ON r.equipment_id = e.equipment_id " +
                       "WHERE r.status = 'ACTIVE' " +
                       "ORDER BY r.return_date";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                rentals.add(extractRentalFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving active rentals: " + e.getMessage());
            throw e;
        }
        return rentals;
    }
    
    // READ - Get rentals by farmer
    public List<Rental> getRentalsByFarmer(int farmerId) throws SQLException {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT r.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "e.equipment_number, " +
                       "CONCAT(e.brand, ' ', e.model) as equipment_name " +
                       "FROM rentals r " +
                       "JOIN farmers f ON r.farmer_id = f.farmer_id " +
                       "JOIN equipment e ON r.equipment_id = e.equipment_id " +
                       "WHERE r.farmer_id = ? " +
                       "ORDER BY r.rental_date DESC";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, farmerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                rentals.add(extractRentalFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving farmer rentals: " + e.getMessage());
            throw e;
        }
        return rentals;
    }
    
    // UPDATE - Update existing rental
    public boolean updateRental(Rental rental) throws SQLException {
        String query = "UPDATE rentals SET farmer_id=?, equipment_id=?, rental_date=?, " +
                       "return_date=?, actual_return_date=?, total_days=?, daily_rate=?, " +
                       "total_amount=?, deposit_amount=?, status=?, purpose=?, notes=? " +
                       "WHERE rental_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, rental.getFarmerId());
            pstmt.setInt(2, rental.getEquipmentId());
            pstmt.setDate(3, rental.getRentalDate());
            pstmt.setDate(4, rental.getReturnDate());
            pstmt.setDate(5, rental.getActualReturnDate());
            pstmt.setInt(6, rental.getTotalDays());
            pstmt.setDouble(7, rental.getDailyRate());
            pstmt.setDouble(8, rental.getTotalAmount());
            pstmt.setDouble(9, rental.getDepositAmount());
            pstmt.setString(10, rental.getStatus());
            pstmt.setString(11, rental.getPurpose());
            pstmt.setString(12, rental.getNotes());
            pstmt.setInt(13, rental.getRentalId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error updating rental: " + e.getMessage());
            throw e;
        }
    }
    
    // UPDATE - Complete rental (return equipment)
    public boolean completeRental(int rentalId, Date actualReturnDate) throws SQLException {
        String query = "UPDATE rentals SET status = 'COMPLETED', actual_return_date = ? " +
                       "WHERE rental_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setDate(1, actualReturnDate);
            pstmt.setInt(2, rentalId);
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error completing rental: " + e.getMessage());
            throw e;
        }
    }
    
    // UPDATE - Cancel rental
    public boolean cancelRental(int rentalId) throws SQLException {
        String query = "UPDATE rentals SET status = 'CANCELLED' WHERE rental_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, rentalId);
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error cancelling rental: " + e.getMessage());
            throw e;
        }
    }
    
    // DELETE - Delete rental
    public boolean deleteRental(int rentalId) throws SQLException {
        String query = "DELETE FROM rentals WHERE rental_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, rentalId);
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting rental: " + e.getMessage());
            throw e;
        }
    }
    
    // STATISTICS - Get total revenue
    public double getTotalRevenue() throws SQLException {
        String query = "SELECT SUM(total_amount) as total FROM rentals WHERE status = 'COMPLETED'";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
        }
        return 0.0;
    }
    
    // STATISTICS - Get rental count by status
    public int getRentalCountByStatus(String status) throws SQLException {
        String query = "SELECT COUNT(*) FROM rentals WHERE status = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    // REPORT - Get revenue by date range (for Jasper Report)
    public List<Rental> getRevenueByDateRange(Date startDate, Date endDate) throws SQLException {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT r.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "e.equipment_number, " +
                       "CONCAT(e.brand, ' ', e.model) as equipment_name " +
                       "FROM rentals r " +
                       "JOIN farmers f ON r.farmer_id = f.farmer_id " +
                       "JOIN equipment e ON r.equipment_id = e.equipment_id " +
                       "WHERE r.rental_date BETWEEN ? AND ? " +
                       "ORDER BY r.rental_date";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setDate(1, startDate);
            pstmt.setDate(2, endDate);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                rentals.add(extractRentalFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting revenue report: " + e.getMessage());
            throw e;
        }
        return rentals;
    }
    
    // Helper method to extract Rental from ResultSet
    private Rental extractRentalFromResultSet(ResultSet rs) throws SQLException {
        Rental rental = new Rental();
        rental.setRentalId(rs.getInt("rental_id"));
        rental.setFarmerId(rs.getInt("farmer_id"));
        rental.setEquipmentId(rs.getInt("equipment_id"));
        rental.setRentalDate(rs.getDate("rental_date"));
        rental.setReturnDate(rs.getDate("return_date"));
        rental.setActualReturnDate(rs.getDate("actual_return_date"));
        rental.setTotalDays(rs.getInt("total_days"));
        rental.setDailyRate(rs.getDouble("daily_rate"));
        rental.setTotalAmount(rs.getDouble("total_amount"));
        rental.setDepositAmount(rs.getDouble("deposit_amount"));
        rental.setStatus(rs.getString("status"));
        rental.setPurpose(rs.getString("purpose"));
        rental.setNotes(rs.getString("notes"));
        rental.setCreatedAt(rs.getTimestamp("created_at"));
        
        // From JOINs
        rental.setFarmerName(rs.getString("farmer_name"));
        rental.setFarmerPhone(rs.getString("farmer_phone"));
        rental.setEquipmentNumber(rs.getString("equipment_number"));
        rental.setEquipmentName(rs.getString("equipment_name"));
        
        return rental;
    }
}