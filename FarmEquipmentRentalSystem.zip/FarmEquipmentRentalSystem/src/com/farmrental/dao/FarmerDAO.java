package com.farmrental.dao;

import com.farmrental.model.Farmer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) Pattern
 * Handles all database operations for Farmer entity
 */
public class FarmerDAO {
    
    private Connection connection;
    
    public FarmerDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new farmer
    public boolean addFarmer(Farmer farmer) throws SQLException {
        String query = "INSERT INTO farmers (first_name, last_name, email, phone, nic, address, farm_location, farm_size) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, farmer.getFirstName());
            pstmt.setString(2, farmer.getLastName());
            pstmt.setString(3, farmer.getEmail());
            pstmt.setString(4, farmer.getPhone());
            pstmt.setString(5, farmer.getNic());
            pstmt.setString(6, farmer.getAddress());
            pstmt.setString(7, farmer.getFarmLocation());
            pstmt.setDouble(8, farmer.getFarmSize());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error adding farmer: " + e.getMessage());
            throw e;
        }
    }
    
    // READ - Get farmer by ID
    public Farmer getFarmerById(int farmerId) throws SQLException {
        String query = "SELECT * FROM farmers WHERE farmer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, farmerId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractFarmerFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving farmer: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    // READ - Get all farmers
    public List<Farmer> getAllFarmers() throws SQLException {
        List<Farmer> farmers = new ArrayList<>();
        String query = "SELECT * FROM farmers ORDER BY farmer_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                farmers.add(extractFarmerFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving farmers: " + e.getMessage());
            throw e;
        }
        return farmers;
    }
    
    // UPDATE - Update existing farmer
    public boolean updateFarmer(Farmer farmer) throws SQLException {
        String query = "UPDATE farmers SET first_name=?, last_name=?, email=?, phone=?, " +
                       "nic=?, address=?, farm_location=?, farm_size=? WHERE farmer_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, farmer.getFirstName());
            pstmt.setString(2, farmer.getLastName());
            pstmt.setString(3, farmer.getEmail());
            pstmt.setString(4, farmer.getPhone());
            pstmt.setString(5, farmer.getNic());
            pstmt.setString(6, farmer.getAddress());
            pstmt.setString(7, farmer.getFarmLocation());
            pstmt.setDouble(8, farmer.getFarmSize());
            pstmt.setInt(9, farmer.getFarmerId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error updating farmer: " + e.getMessage());
            throw e;
        }
    }
    
    // DELETE - Delete farmer
    public boolean deleteFarmer(int farmerId) throws SQLException {
        String query = "DELETE FROM farmers WHERE farmer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, farmerId);
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting farmer: " + e.getMessage());
            throw e;
        }
    }
    
    // SEARCH - Search farmers by name or phone
    public List<Farmer> searchFarmers(String searchTerm) throws SQLException {
        List<Farmer> farmers = new ArrayList<>();
        String query = "SELECT * FROM farmers WHERE first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR email LIKE ? OR farm_location LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            pstmt.setString(5, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                farmers.add(extractFarmerFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error searching farmers: " + e.getMessage());
            throw e;
        }
        return farmers;
    }
    
    // CHECK - Check if email exists
    public boolean emailExists(String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM farmers WHERE email = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // CHECK - Check if NIC exists
    public boolean nicExists(String nic) throws SQLException {
        String query = "SELECT COUNT(*) FROM farmers WHERE nic = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, nic);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // Helper method to extract Farmer from ResultSet
    private Farmer extractFarmerFromResultSet(ResultSet rs) throws SQLException {
        Farmer farmer = new Farmer();
        farmer.setFarmerId(rs.getInt("farmer_id"));
        farmer.setFirstName(rs.getString("first_name"));
        farmer.setLastName(rs.getString("last_name"));
        farmer.setEmail(rs.getString("email"));
        farmer.setPhone(rs.getString("phone"));
        farmer.setNic(rs.getString("nic"));
        farmer.setAddress(rs.getString("address"));
        farmer.setFarmLocation(rs.getString("farm_location"));
        farmer.setFarmSize(rs.getDouble("farm_size"));
        farmer.setCreatedAt(rs.getTimestamp("created_at"));
        return farmer;
    }
}