package com.farmrental.dao;

import com.farmrental.model.Equipment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for Equipment entity
 * Handles all database operations for equipment
 */
public class EquipmentDAO {
    
    private Connection connection;
    
    public EquipmentDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new equipment
    public boolean addEquipment(Equipment equipment) throws SQLException {
        String query = "INSERT INTO equipment (category_id, equipment_number, brand, model, year, " +
                       "fuel_type, condition_status, status, horse_power) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, equipment.getCategoryId());
            pstmt.setString(2, equipment.getEquipmentNumber());
            pstmt.setString(3, equipment.getBrand());
            pstmt.setString(4, equipment.getModel());
            pstmt.setInt(5, equipment.getYear());
            pstmt.setString(6, equipment.getFuelType());
            pstmt.setString(7, equipment.getConditionStatus());
            pstmt.setString(8, equipment.getStatus());
            pstmt.setInt(9, equipment.getHorsePower());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error adding equipment: " + e.getMessage());
            throw e;
        }
    }
    
    // READ - Get equipment by ID (with category info)
    public Equipment getEquipmentById(int equipmentId) throws SQLException {
        String query = "SELECT e.*, ec.category_name, ec.daily_rate " +
                       "FROM equipment e " +
                       "JOIN equipment_categories ec ON e.category_id = ec.category_id " +
                       "WHERE e.equipment_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, equipmentId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractEquipmentFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving equipment: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    // READ - Get all equipment (with category info)
    public List<Equipment> getAllEquipment() throws SQLException {
        List<Equipment> equipmentList = new ArrayList<>();
        String query = "SELECT e.*, ec.category_name, ec.daily_rate " +
                       "FROM equipment e " +
                       "JOIN equipment_categories ec ON e.category_id = ec.category_id " +
                       "ORDER BY e.equipment_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                equipmentList.add(extractEquipmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving equipment: " + e.getMessage());
            throw e;
        }
        return equipmentList;
    }
    
    // READ - Get available equipment only
    public List<Equipment> getAvailableEquipment() throws SQLException {
        List<Equipment> equipmentList = new ArrayList<>();
        String query = "SELECT e.*, ec.category_name, ec.daily_rate " +
                       "FROM equipment e " +
                       "JOIN equipment_categories ec ON e.category_id = ec.category_id " +
                       "WHERE e.status = 'AVAILABLE' " +
                       "ORDER BY e.category_id, e.brand";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                equipmentList.add(extractEquipmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving available equipment: " + e.getMessage());
            throw e;
        }
        return equipmentList;
    }
    
    // UPDATE - Update existing equipment
    public boolean updateEquipment(Equipment equipment) throws SQLException {
        String query = "UPDATE equipment SET category_id=?, equipment_number=?, brand=?, model=?, " +
                       "year=?, fuel_type=?, condition_status=?, status=?, horse_power=? " +
                       "WHERE equipment_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, equipment.getCategoryId());
            pstmt.setString(2, equipment.getEquipmentNumber());
            pstmt.setString(3, equipment.getBrand());
            pstmt.setString(4, equipment.getModel());
            pstmt.setInt(5, equipment.getYear());
            pstmt.setString(6, equipment.getFuelType());
            pstmt.setString(7, equipment.getConditionStatus());
            pstmt.setString(8, equipment.getStatus());
            pstmt.setInt(9, equipment.getHorsePower());
            pstmt.setInt(10, equipment.getEquipmentId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error updating equipment: " + e.getMessage());
            throw e;
        }
    }
    
    // UPDATE - Update equipment status
    public boolean updateEquipmentStatus(int equipmentId, String status) throws SQLException {
        String query = "UPDATE equipment SET status = ? WHERE equipment_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, equipmentId);
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error updating equipment status: " + e.getMessage());
            throw e;
        }
    }
    
    // DELETE - Delete equipment
    public boolean deleteEquipment(int equipmentId) throws SQLException {
        String query = "DELETE FROM equipment WHERE equipment_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, equipmentId);
            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting equipment: " + e.getMessage());
            throw e;
        }
    }
    
    // SEARCH - Search equipment by brand, model, or number
    public List<Equipment> searchEquipment(String searchTerm) throws SQLException {
        List<Equipment> equipmentList = new ArrayList<>();
        String query = "SELECT e.*, ec.category_name, ec.daily_rate " +
                       "FROM equipment e " +
                       "JOIN equipment_categories ec ON e.category_id = ec.category_id " +
                       "WHERE e.brand LIKE ? OR e.model LIKE ? OR e.equipment_number LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                equipmentList.add(extractEquipmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error searching equipment: " + e.getMessage());
            throw e;
        }
        return equipmentList;
    }
    
    // CHECK - Check if equipment number exists
    public boolean equipmentNumberExists(String equipmentNumber) throws SQLException {
        String query = "SELECT COUNT(*) FROM equipment WHERE equipment_number = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, equipmentNumber);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // STATISTICS - Get equipment count by status
    public int getEquipmentCountByStatus(String status) throws SQLException {
        String query = "SELECT COUNT(*) FROM equipment WHERE status = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    // Helper method to extract Equipment from ResultSet
    private Equipment extractEquipmentFromResultSet(ResultSet rs) throws SQLException {
        Equipment equipment = new Equipment();
        equipment.setEquipmentId(rs.getInt("equipment_id"));
        equipment.setCategoryId(rs.getInt("category_id"));
        equipment.setEquipmentNumber(rs.getString("equipment_number"));
        equipment.setBrand(rs.getString("brand"));
        equipment.setModel(rs.getString("model"));
        equipment.setYear(rs.getInt("year"));
        equipment.setFuelType(rs.getString("fuel_type"));
        equipment.setConditionStatus(rs.getString("condition_status"));
        equipment.setStatus(rs.getString("status"));
        equipment.setHorsePower(rs.getInt("horse_power"));
        equipment.setCreatedAt(rs.getTimestamp("created_at"));
        
        // From JOIN with equipment_categories
        equipment.setCategoryName(rs.getString("category_name"));
        equipment.setDailyRate(rs.getDouble("daily_rate"));
        
        return equipment;
    }
}