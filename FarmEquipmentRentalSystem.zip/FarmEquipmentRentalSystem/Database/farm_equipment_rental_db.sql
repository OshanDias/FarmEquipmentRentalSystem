CREATE DATABASE  IF NOT EXISTS `farm_equipment_rental_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `farm_equipment_rental_db`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: farm_equipment_rental_db
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `equipment_number` varchar(20) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` int(11) NOT NULL,
  `fuel_type` enum('Diesel','Petrol','Electric','Manual') DEFAULT 'Diesel',
  `condition_status` enum('Excellent','Good','Fair') DEFAULT 'Good',
  `status` enum('AVAILABLE','RENTED','MAINTENANCE') DEFAULT 'AVAILABLE',
  `horse_power` int(11) DEFAULT NULL COMMENT 'Engine power in HP',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`equipment_id`),
  UNIQUE KEY `equipment_number` (`equipment_number`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `equipment_categories` (`category_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,1,'TRC-001','John Deere','5075E',2022,'Diesel','Excellent','AVAILABLE',75,'2026-01-26 07:11:09'),(2,1,'TRC-002','Massey Ferguson','MF 240',2021,'Diesel','Good','AVAILABLE',50,'2026-01-26 07:11:09'),(3,1,'TRC-003','New Holland','TD5.110',2023,'Diesel','Excellent','AVAILABLE',110,'2026-01-26 07:11:09'),(4,2,'HRV-001','John Deere','S780',2022,'Diesel','Excellent','AVAILABLE',445,'2026-01-26 07:11:09'),(5,2,'HRV-002','Case IH','Axial-Flow 8250',2021,'Diesel','Good','AVAILABLE',425,'2026-01-26 07:11:09'),(6,3,'PLW-001','Lemken','EurOpal 7X',2023,'Manual','Excellent','AVAILABLE',0,'2026-01-26 07:11:09'),(7,3,'PLW-002','Kuhn','Multi-Master',2022,'Manual','Good','AVAILABLE',0,'2026-01-26 07:11:09'),(8,4,'SPR-001','Hardi','Commander',2022,'Diesel','Excellent','AVAILABLE',0,'2026-01-26 07:11:09'),(9,4,'SPR-002','Amazone','UX 5200',2023,'Diesel','Excellent','AVAILABLE',0,'2026-01-26 07:11:09'),(10,5,'SED-001','Vaderstad','Spirit 400C',2022,'Manual','Good','AVAILABLE',0,'2026-01-26 07:11:09'),(11,5,'SED-002','Kuhn','Maxima 2',2023,'Manual','Excellent','AVAILABLE',0,'2026-01-26 07:11:09');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_categories`
--

DROP TABLE IF EXISTS `equipment_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `daily_rate` decimal(10,2) NOT NULL,
  `description` text,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_categories`
--

LOCK TABLES `equipment_categories` WRITE;
/*!40000 ALTER TABLE `equipment_categories` DISABLE KEYS */;
INSERT INTO `equipment_categories` VALUES (1,'Tractor',5500.00,'Heavy-duty tractors for plowing and general farm work'),(2,'Harvester',12000.00,'Combine harvesters for crop harvesting'),(3,'Plow',2500.00,'Plowing equipment for land preparation'),(4,'Sprayer',3000.00,'Pesticide and fertilizer spraying equipment'),(5,'Seeder',2800.00,'Seeding and planting machinery');
/*!40000 ALTER TABLE `equipment_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farmers`
--

DROP TABLE IF EXISTS `farmers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `farmers` (
  `farmer_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `address` text,
  `farm_location` varchar(100) DEFAULT NULL,
  `farm_size` decimal(10,2) DEFAULT NULL COMMENT 'Farm size in acres',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`farmer_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nic` (`nic`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farmers`
--

LOCK TABLES `farmers` WRITE;
/*!40000 ALTER TABLE `farmers` DISABLE KEYS */;
INSERT INTO `farmers` VALUES (1,'Nimal','Perera','nimal.perera@farm.lk','0771234567','912345678V','No. 45, Galle Road, Matara','Matara District',15.50,'2026-01-26 07:11:09'),(2,'Kamala','Silva','kamala.silva@farm.lk','0712345678','887654321V','No. 78, Kandy Road, Kurunegala','Kurunegala District',22.00,'2026-01-26 07:11:09'),(3,'Sunil','Fernando','sunil.fernando@farm.lk','0763456789','952345678V','No. 12, Main Street, Anuradhapura','Anuradhapura District',30.50,'2026-01-26 07:11:09'),(4,'Malini','Jayasinghe','malini.j@farm.lk','0724567890','865432109V','No. 34, Temple Road, Polonnaruwa','Polonnaruwa District',18.00,'2026-01-26 07:11:09'),(5,'Pradeep','Wickramasinghe','pradeep.w@farm.lk','0775678901','903456789V','No. 56, Lake Road, Ampara','Ampara District',25.50,'2026-01-26 07:11:09'),(6,'Test','Farmer','testfarmer@farm.lk','0771234999','991234567V','Test Address','Test District',20.00,'2026-01-26 07:21:58');
/*!40000 ALTER TABLE `farmers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rentals` (
  `rental_id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `rental_date` date NOT NULL,
  `return_date` date NOT NULL,
  `actual_return_date` date DEFAULT NULL,
  `total_days` int(11) NOT NULL,
  `daily_rate` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `deposit_amount` decimal(10,2) NOT NULL,
  `status` enum('ACTIVE','COMPLETED','CANCELLED') DEFAULT 'ACTIVE',
  `purpose` text COMMENT 'Purpose of rental (plowing, harvesting, etc)',
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rental_id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `equipment_id` (`equipment_id`),
  CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`farmer_id`) ON DELETE CASCADE,
  CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentals`
--

LOCK TABLES `rentals` WRITE;
/*!40000 ALTER TABLE `rentals` DISABLE KEYS */;
INSERT INTO `rentals` VALUES (1,1,1,'2026-01-20','2026-01-25',NULL,5,5500.00,27500.00,10000.00,'ACTIVE','Land preparation for paddy cultivation',NULL,'2026-01-26 07:11:09'),(2,2,4,'2026-01-18','2026-01-23',NULL,5,12000.00,60000.00,20000.00,'ACTIVE','Harvesting rice crop',NULL,'2026-01-26 07:11:09'),(3,3,6,'2026-01-15','2026-01-20',NULL,5,2500.00,12500.00,5000.00,'COMPLETED','Plowing for vegetable cultivation',NULL,'2026-01-26 07:11:09'),(4,4,8,'2026-01-22','2026-01-27',NULL,5,3000.00,15000.00,5000.00,'ACTIVE','Spraying pesticides on crops',NULL,'2026-01-26 07:11:09'),(5,5,10,'2026-01-10','2026-01-15',NULL,5,2800.00,14000.00,5000.00,'COMPLETED','Seeding corn fields',NULL,'2026-01-26 07:11:09');
/*!40000 ALTER TABLE `rentals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-26 13:38:21
